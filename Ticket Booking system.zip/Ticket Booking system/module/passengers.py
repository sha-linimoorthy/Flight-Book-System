class Passenger:
    def __init__(self, name, age,email, flightNo):
        self.name = name
        self.age = age
        self.email = email
        self.flightNo = flightNo
