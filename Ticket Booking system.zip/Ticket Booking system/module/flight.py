class Flight:
    def __init__(self, flightNo, flightName, arrival, departure, duration, destination, price, seats_available):
        self.flightNo = flightNo
        self.flightName = flightName
        self.arrival = arrival
        self.departure = departure
        self.duration = duration
        self.destination = destination
        self.price = price
        self.seats_available = seats_available
