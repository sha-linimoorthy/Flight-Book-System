import sqlite3
from module.flight import Flight
from module.passengers import Passenger

class BookingSystem:
    def __init__(self, db_name):
        self.conn = sqlite3.connect(db_name)
        self.c = self.conn.cursor()
        self.create_tables()

    def create_tables(self):
        self.c.execute('''CREATE TABLE IF NOT EXISTS flights
                         (flightNo TEXT PRIMARY KEY, flightName TEXT,
                         arrival TEXT, departure TEXT, duration TEXT,
                         destination TEXT, price REAL, seats_available INTEGER)''')
        self.c.execute('''CREATE TABLE IF NOT EXISTS passengers (
                        passenger_id INTEGER PRIMARY KEY,
                        name TEXT,
                        age INTEGER,
                        email TEXT,
                        flightNo INTEGER,
                        seatNo INTEGER,
                        FOREIGN KEY (flightNo) REFERENCES flights(flightNo)
);
''')
        self.conn.commit()

    def add_flight(self, flight):
        self.c.execute("INSERT INTO flights (flightNo, flightName, arrival, departure, duration, destination, price, seats_available) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                       (flight.flightNo, flight.flightName, flight.arrival,
                        flight.departure, flight.duration, flight.destination,
                        flight.price, flight.seats_available))
        self.conn.commit()
        print("Flight added successfully.")
    def add_passenger(self, passenger):
        self.c.execute("SELECT seats_available FROM flights WHERE flightNo=?", (passenger.flightNo,))
        row = self.c.fetchone()
        if row is not None:
            seats_available = row[0]
            if seats_available > 0:
                self.c.execute("INSERT INTO passengers (name, age, email, flightNo) VALUES (?, ?, ?, ?)",
                           (passenger.name, passenger.age, passenger.email, passenger.flightNo))
                self.c.execute("UPDATE flights SET seats_available = seats_available - 1 WHERE flightNo=?", (passenger.flightNo,))
                self.conn.commit()
                print("Passenger added successfully.")
            else:
                print("No seats available for this flight.")
        else:
            print("Flight not found.")


    def close_connection(self):
        self.conn.close()
