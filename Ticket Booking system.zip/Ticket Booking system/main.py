from module.flight import Flight
from module.passengers import Passenger
from module.booking_system import BookingSystem

def main():
    booking_system = BookingSystem('flights.db')
    
    while True:
        print("\n1. Add Flight\n2. Add Passenger\n3. Exit")
        choice = input("Enter your choice: ")
        
        if choice == '1':
            flightNo = input("Enter flight number: ")
            flightName=input("Enter flight name: ")
            arrival = input("Enter the date and time of arrival: ")
            destination = input("Enter destination: ")
            departure = input("Enter departure time: ")
            duration = input("Enter duration: ")
            price = float(input("Enter price: "))
            seats_available = int(input("Enter seats available: "))
            flight = Flight(flightNo, flightName, arrival, departure, duration, destination, price, seats_available)
            booking_system.add_flight(flight)
            
        elif choice == '2':
            name = input("Enter passenger name: ")
            age = int(input("Enter passenger age: "))
            email = input("Enter passenger email: ")
            flightNo = input("Enter flight ID: ")
            passenger = Passenger(name, age, email, flightNo)
            booking_system.add_passenger(passenger)
            
        elif choice == '3':
            booking_system.close_connection()
            print("Exiting program.")
            break
            
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
