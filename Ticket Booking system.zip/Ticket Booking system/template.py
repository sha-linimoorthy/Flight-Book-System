import os
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO,format="[%(asctime)s] : %(message)s :")

list_of_files =[
    "main.py",
    r"db/flights.py",
    r"module/__init__.py",
    r"module/flight.py",
    r"module/booking_system.py"
]

for file in list_of_files:
    filepath = Path(file)
    filedir, filename =os.path.split(filepath)

    if filedir!="":
        os.makedirs(filedir, exist_ok=True) #if exists raise no error
        logging.info(f"Directory {filedir} created.")
    
    if (not os.path.exists(filepath)):
        with open(filepath,"w",encoding="utf-8") as f:
            pass
        logging.info(f"File {filepath} has been created.")

    else:
        logging.info(f"File {filepath} already existed.")
